package Vortrag�ben;

import java.util.Scanner;

public class HauptProgVortrag {	//mit ID Zaehler jz statt indicator 
							//und mit do while Schleife statt while nur 

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int indicator=0;
		Vortrag v1 = new Vortrag("Mag.", "Sarah", "Malik");
		
		do {		
			System.out.println("(1)Anmelden\n(2)Abmelden\n(3)Ausgabe\n(4)Beenden");
			if( indicator== 1) {
				v1.anmelden();
			}
			else if ( indicator== 2) {
				v1.abmelden();
			}
			else if ( indicator== 3) {
				System.out.println(v1);
			}
		}while( indicator!= 4); //zb wird um 2 aufeinmal erhoeht od 2 weniger aufeinmal --> Abbruch
		System.out.println(v1);
		
		
		s.close();
	}

}


