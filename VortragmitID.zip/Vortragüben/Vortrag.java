package Vortrag�ben;

public class Vortrag {

		private static int zaehler=0;
		private final int id;
		private String vorname;
		private String nachname;
		private String titel;
		private int anmeldezahl;
		
		
		
		
		public Vortrag(String titelInp, String vornameInp, String nachnameInp) {
			this.anmeldezahl=0;
			this.id=Vortrag.zaehler++;
			this.vorname = vornameInp;
			this.nachname = nachnameInp;
			this.titel = titelInp;
		}
		
		public void anmelden() {
			this.anmeldezahl++ ;
		}
		
		public void abmelden() {
			if (this.anmeldezahl <= 0) return;
			this.anmeldezahl--; //keine Leerezcihen vor -- 
		}
		
		public String toString() {
			return  
				"[ID" +
				+ this.id + ", " 
				+"[Vorname:" + this.vorname 
				+ ", Nachname:" + this.nachname 
				+ ", Titel:" + this.titel 
				+ ", Anmeldezahl:" + this.anmeldezahl 
				+  "]";
		}
	
		
	}


