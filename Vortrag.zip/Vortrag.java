package oop_hausuebung2;

public class Vortrag 
{
	private String vorname;
	private String nachname;
	private String titel;
	private int anmeldezahl;
	
	public Vortrag(String titelinp, String vornameinp, String nachnameinp) 
	{
		this.vorname = vornameinp;
		this.nachname = nachnameinp ;
		this.titel = titelinp;
		this.anmeldezahl = 0;
	}
	
	public void anmelden ()
	{
		this.anmeldezahl ++;
	}
	
	public void abmelden ()
	{
		if (anmeldezahl <= 0) return;
		this.anmeldezahl --;
	}
	
	public String toString() 
	{
		return "[Vorname:" +
			this.vorname + ", Nachname:" +
			this.nachname + ", Titel:" +
			this.titel + ", Anmeldezahl:" + 
			this.anmeldezahl +  
			"]";
	}

}
