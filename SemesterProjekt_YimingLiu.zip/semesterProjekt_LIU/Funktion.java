package semesterProjekt_LIU;

public enum Funktion {
	  MATROSE(3), 
	  ZIMMERMANN(4), 
	  SCHMIED(4), 
	  SMUTJE(5), 
	  STEUERMANN(6);

	 private final int gehalt;
	 Funktion(final int gehaltInp) {
		 	gehalt = gehaltInp;
		 }
	 
	 public int getGehalt() {
		 return gehalt;
		 }
}

