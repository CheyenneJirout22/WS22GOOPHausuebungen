package semesterProjekt_LIU;

import java.util.ArrayList;

public class Besatzung extends Person {
	private Funktion funktion;
	
	public Besatzung(String nameInp, Funktion funktionInp) throws Exception {
		super(nameInp);
		this.funktion = funktionInp;
	}
	
	public void machtAusbildung(Funktion neuFunktion, ArrayList<Segelschiff>schiffListe) throws Exception {
		if (this.checkAufSchiff(schiffListe)!=null) {
			throw new Exception("Die Besatzung: " + getNamePerson() + " befindet momentan auf einen Schiff und kann daher keine Ausbildung machen!");
		}
		if (neuFunktion.getGehalt() <= this.funktion.getGehalt()) {
			throw new Exception("Der Gehalt der gew�nschten neuen Funktion ist nicht h�her als die jetztige Funktion!");
		}
		else {
			this.funktion = neuFunktion;
		}
	}
	
	//f�r istSeeklar
	public Funktion getFunktion() {
		return this.funktion;
	}
	
    public String toString() {
    	  return super.toString() + " " + this.funktion + "]";
    }
}
