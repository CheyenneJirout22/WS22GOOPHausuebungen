package semesterProjekt_LIU;

import java.util.ArrayList;

public class Segelschiff {
	private String name;
	private final int anzMasten;
	private final int maxGesamtsegelflaeche;
	private ArrayList<Person> personList;
	
	public Segelschiff(String nameInp, int anzMastenInp, int maxGesamtsegelflaecheInp) throws Exception {
//		for (Segelschiff nameSchiff : this.nameSchiffList) {
//			if (nameSchiff.equals(nameInp)) {
//				throw new Exception("der Name existiert schon! Bitte einen neuen Name ausdenken!");
//		}
		this.name = nameInp;
		
		if (anzMastenInp < 1) {
			throw new Exception("zu wenig Masten!");
		}
		else if (anzMastenInp > 4) {
			throw new Exception("zu viel Masten!");
		}
		this.anzMasten = anzMastenInp;
		
		if (maxGesamtsegelflaecheInp > (anzMastenInp * 75)) {
			throw new Exception ("maximale Segelfl�che �berstritten");
		}
		this.maxGesamtsegelflaeche = maxGesamtsegelflaecheInp;
		
		this.personList = new ArrayList<Person>();
	}

	public Segelschiff(String nameInp) throws Exception {
		this(nameInp, 3, 150);
	}
	
	//getName wird f�r anheuern Methode in Person benutzt
	public String getName() {
		return name;
	}
	
	//addPerson wird f�r anheuern Methode in Person benutzt
	public void addPerson(Person p) {
		this.personList.add(p);
	}
	
	//getPersonList wird f�r anheuern Methode in Person benutzt
	public ArrayList<Person> getPersonList() {
		return personList;
	}
	
	public boolean istSeeklar(){
		int anzKapitant = 0;
		int anzSmutje = 0;
		int anzZimmermann = 0;
		int anzMatrose = 0;
		
		//z�hle mal nach, was f�r Personen und wieviele davon auf den Schiff sind 
		//�berpr�fen, ob ein Offizier mit Kapit�npatent sich auf dem Schiff befindet
		for (Person p1 : this.personList) {
			if (p1 instanceof Offizier) {
				Offizier o1 = (Offizier)p1;
				if (o1.getPatentStatus()) {
					anzKapitant ++;
				}
			}
			else {
				Besatzung b1 = (Besatzung)p1;
				if (b1.getFunktion() == Funktion.SMUTJE) {
					anzSmutje ++;
				} else if (b1.getFunktion() == Funktion.ZIMMERMANN) {
					anzZimmermann++;
				} else if (b1.getFunktion() == Funktion.MATROSE) {
					anzMatrose ++;
				}
			}
		}
		
		return anzKapitant > 0 && anzSmutje > 0 && anzZimmermann > 0 && anzMatrose >= 2 * this.anzMasten;
	}
	
	public String statistik(ArrayList<Segelschiff> schiffList) {
		String statistik = "";
		int anzSchiffe1Mast = 0;
		int anzSchiffe2Mast = 0;
		int anzSchiffe3Mast = 0;
		int anzSchiffe4Mast = 0;
		
		int segelflaeche1Mast = 0;
		int segelflaeche2Mast = 0;
		int segelflaeche3Mast = 0;
		int segelflaeche4Mast = 0;
		
		for (Segelschiff s : schiffList) {
			if(s.anzMasten == 1)
			{
				anzSchiffe1Mast++;
				segelflaeche1Mast += s.maxGesamtsegelflaeche;
			}
			if(s.anzMasten == 2)
			{
				anzSchiffe2Mast++;
				segelflaeche2Mast += s.maxGesamtsegelflaeche;
			}
			if(s.anzMasten == 3)
			{
				anzSchiffe3Mast++;
				segelflaeche3Mast += s.maxGesamtsegelflaeche;
			}
			if(s.anzMasten == 4)
			{
				anzSchiffe4Mast++;
				segelflaeche4Mast += s.maxGesamtsegelflaeche;
			}
		}
		
//		System.out.println("1 Mast: " + anzSchiffe1Mast+" Schiffe," +segelflaeche1Mast +" m2 Segel");
//		System.out.println("2 Mast: " + anzSchiffe2Mast+" Schiffe," +segelflaeche2Mast +" m2 Segel");
//		System.out.println("3 Mast: " + anzSchiffe3Mast+" Schiffe," +segelflaeche3Mast +" m2 Segel");
//		System.out.println("4 Mast: " + anzSchiffe4Mast+" Schiffe," +segelflaeche4Mast +" m2 Segel");
		statistik = ("1 Mast: " + anzSchiffe1Mast + " Schiffe," + segelflaeche1Mast + " m2 Segel\n" +
				"2 Mast: " + anzSchiffe2Mast + " Schiffe," + segelflaeche2Mast + " m2 Segel\n" +
				"3 Mast: " + anzSchiffe3Mast+" Schiffe," +segelflaeche3Mast +" m2 Segel\n" + 
				"4 Mast: " + anzSchiffe4Mast+" Schiffe," +segelflaeche4Mast +" m2 Segel");
		return statistik;
	}
	
	public String toString() {
		int offizierCounter = 0;
	    int besatzungCounter = 0;
	    for (Person p : personList) {
	    	if (p instanceof Offizier) {
	            offizierCounter++;
	            } else {
	            	besatzungCounter++;
	            }
	    	}
	    return "Segelschiff:[" + 
	        	name + ", " +
	        	anzMasten + " Masten, " +
	        	maxGesamtsegelflaeche + " m2 maximale Gesamtsegelfl�che, " +
	        	offizierCounter + " Offizier(e), " + 
	        	besatzungCounter + " Besatzung]";
	    }
}
