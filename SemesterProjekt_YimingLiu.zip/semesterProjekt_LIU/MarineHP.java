package semesterProjekt_LIU;

import java.util.ArrayList;

public class MarineHP {

	public static void main(String[] args) {
		try {
		//Segelschiff
		//eine Liste f�r alle erzeugte Schiffe krearieren
		ArrayList schiffErzeugtAll = new ArrayList<Segelschiff>();
		
		Segelschiff s1 = new Segelschiff("Fatui", 2, 110);
		System.out.println(s1);
		Segelschiff s2 = new Segelschiff("Big G");
		System.out.println(s2);
		Segelschiff s3 = new Segelschiff("Spurs", 4, 280);
		Segelschiff s4 = new Segelschiff("Single Triple", 1, 30);
		//Segelschiff erzeugen, aber falsch, weil die Anzahl der Masten zu viel ist
		//Segelschiff s5 = new Segelschiff("Lakers", 6, 140);
		
		schiffErzeugtAll.add(s1);
		schiffErzeugtAll.add(s2);
		schiffErzeugtAll.add(s3);
		schiffErzeugtAll.add(s4);
		
		
	
		//Person
		Offizier o1 = new Offizier("Bob", Rang.LIEUTENANT, false);
		System.out.println(o1);
		Offizier o2 = new Offizier("Messi", Rang.COMMODORE);
		System.out.println(o2);
		Offizier o3 = new Offizier("P", Rang.COMMODORE, true);
		
		Besatzung b1 = new Besatzung("Aaron", Funktion.MATROSE);
		System.out.println(b1);
		Besatzung b2 = new Besatzung("Miller", Funktion.ZIMMERMANN);
		Besatzung b3 = new Besatzung("Swaggy P", Funktion.SMUTJE);
		Besatzung b4 = new Besatzung("MJ", Funktion.MATROSE);
		Besatzung b5 = new Besatzung("Lebron", Funktion.SCHMIED);
		Besatzung b6 = new Besatzung("Luka", Funktion.MATROSE);
		System.out.println(b6);
		Besatzung b7 = new Besatzung("Joel", Funktion.MATROSE);
		
		
		//anheuern
		o1.anheuern(s1, schiffErzeugtAll);		
		b1.anheuern(s1, schiffErzeugtAll);
		
		//anheuern, aber falsch, weil der o1 schon auf einen Schiff ist
		//o1.anheuern(s4, schiffErzeugtAll);
		
		//anheuern, aber falsch, weil es auf den Schiff s1 schon einen Offizier mit dem gleichen Rang und Kapit�npatent gibt
//		o2.anheuern(s1, schiffErzeugtAll);
//		o3.anheuern(s1, schiffErzeugtAll);
		
		
		
		//machtAusbildung
		b6.machtAusbildung(Funktion.STEUERMANN, schiffErzeugtAll);
		System.out.println(b6);
		
		//machtAusbildung, aber falsch, weil der b1 auf einen Schiff ist und daher keine Ausbildung machen darf
		//b1.machtAusbildung(Funktion.SCHMIED, schiffErzeugtAll);
		
		//machtAusbildung, aber falsch, weil der b5 keine bessere Funktion dadurch bekommen h�tte
		//b5.machtAusbildung(Funktion.MATROSE, schiffErzeugtAll);


		//verlassen
		o1.verlassen(s1, schiffErzeugtAll);
		b1.verlassen(s1, schiffErzeugtAll);
		System.out.println(s1);
		//break
		System.out.println("-------------------------------------------------------------------------------------------------------");
		
		//istSeeklar
		o2.anheuern(s4, schiffErzeugtAll);
		b1.anheuern(s4, schiffErzeugtAll);
		b7.anheuern(s4, schiffErzeugtAll);
		b3.anheuern(s4, schiffErzeugtAll);
		b2.anheuern(s4, schiffErzeugtAll);
		
		System.out.println(s4.istSeeklar());
		System.out.println("ist " + s4 + " Seeklar? " + (s4.istSeeklar()? "Ja!" : "Nein!"));
		System.out.println(s4.getPersonList());
		
		//Statistik
		System.out.println(s2.statistik(schiffErzeugtAll));		
		
		} catch (Exception e) {
			System.out.println("Fehler: " + e.getMessage());
		}
		
	}

}
