package semesterProjekt_LIU;

import java.util.ArrayList;

public class Person {
	private static int personIDzaehler = 10001;
	private final String name;
	private final int personID;
//	private Segelschiff segelschiffListAktiv;
	private ArrayList<Segelschiff> segelschiffListVergangenheit;

	public Person(String nameInp) throws Exception {
		this.name = nameInp;
		this.personID = personIDzaehler++;
		// this.segelschiffListAktiv = new ArrayList<Segelschiff>();
		this.segelschiffListVergangenheit = new ArrayList<Segelschiff>();
	}

	public void anheuern(Segelschiff segelschiffInp, ArrayList<Segelschiff> schiffList) throws Exception {
		Segelschiff istSchonAngeheuert = this.checkAufSchiff(schiffList);

		if (istSchonAngeheuert!=null) {
			throw new Exception("die Person: " + this.name + " befindet sich bereits auf einen Schiff! Und zwar auf: " + istSchonAngeheuert.getName());
		}
		else if (this instanceof Offizier && (checkOffizier(segelschiffInp, (Offizier)this))) {
				throw new Exception("Es gibt schon einen Offizier mit dem gleichen Rang und Kapit�npatent auf dem Schiff");
		}
		
		segelschiffInp.addPerson(this);
		this.segelschiffListVergangenheit.add(segelschiffInp);
	}

	public Segelschiff checkAufSchiff(ArrayList<Segelschiff> schiffList) {
		Segelschiff schiffAktiv = null;
		for (Segelschiff s : schiffList) {
			ArrayList<Person> crew = s.getPersonList();
			for (Person p : crew) {
				if (p.personID == this.personID) {
					schiffAktiv = s;
				}
			}
		}
		return schiffAktiv;
	}
	
	public boolean checkOffizier(Segelschiff schiffInp, Offizier angeheuertePerson){
		boolean konfliktOffizier=false;
		ArrayList<Person> crew = schiffInp.getPersonList();
		for (Person p : crew) {
			if (p instanceof Offizier) {
				Offizier o = (Offizier)p ;
				if(o.getRang().equals(angeheuertePerson.getRang())) {
					if(o.getPatentStatus()==true && angeheuertePerson.getPatentStatus()==true) {
						konfliktOffizier=true;
					}	
				}
				
			}
		}		
		return konfliktOffizier;
	}

	public void verlassen(Segelschiff schiffInp, ArrayList<Segelschiff> schiffList) throws Exception {
		boolean aufSchiff = false;
		ArrayList<Person> crew = schiffInp.getPersonList();
		for (Person p : crew) {
			if (p.personID == this.personID) {
				aufSchiff = true;
			}
		}
		if (!aufSchiff) {
			throw new Exception(this.name + " befindet gar nicht auf den Schiff: " + schiffInp);
		} else {
			schiffInp.getPersonList().remove(this);
		}

		if (!this.segelschiffListVergangenheit.contains(schiffInp)) {
			this.segelschiffListVergangenheit.add(schiffInp);
		}
	}

	//getNamePerson wird f�r Besatzung benutzt
	public String getNamePerson() {
		return this.name;
	}

//	public ArrayList<Segelschiff> getSchiffAktiv() {
//		return this.segelschiffListAktiv;
//	}

	public String toString() {
		String rolle = "";
		// �berpr�fen, ob die Person Offizier ist oder nicht
		if (this instanceof Offizier) {
			rolle = "O";
		} else {
			rolle = "B";
		}
		return "[" + rolle + this.personID + " " + this.name;
	}
}
