package semesterProjekt_LIU;

public enum Rang {
	MASTER, LIEUTENANT, COMMANDER, CAPTAIN, COMMODORE
}
