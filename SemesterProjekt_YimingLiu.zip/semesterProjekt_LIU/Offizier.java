package semesterProjekt_LIU;

public class Offizier extends Person {
	private Rang rang;
	private boolean hatPatent;
	
	public Offizier(String nameInp, Rang rangInp, boolean hatPatentInp) throws Exception {
		super(nameInp);
		//gehen die Range durch und �berpr�fe, ob der eingegebene Rang existiert
		this.rang = rangInp;
		if (this.rang.equals(Rang.COMMODORE)) {
			this.hatPatent = true;
		}
		else {
			this.hatPatent = hatPatentInp;
		}
	}
	public Offizier(String nameInp, Rang rangInp) throws Exception {
		super(nameInp);
		this.rang = rangInp;
		if (this.rang.equals(Rang.COMMODORE)) {
			this.hatPatent = true;
		}
		else {
			this.hatPatent = false;
		}
	}

	public void machtPatent() throws Exception {
		if (this.rang.compareTo(Rang.COMMANDER) < 0) {
			throw new Exception("der Offizier muss zumindest den Rang eines Commander haben!");
		}
		else if (this.hatPatent == true) {
			throw new Exception("der Offizier hat schon das Kapit�npatent! Jeder Offizier darf nur einmal Patent machen!");
		}
		else {
			this.hatPatent = true;
		}
	}
	
	//f�r checkOffizier
	public Rang getRang() {
		return this.rang;
	}
	//f�r checkOffizier
    public boolean getPatentStatus() {
        return this.hatPatent;
    }
    
    public String toString() {
        return super.toString() + " " + this.rang + (this.hatPatent ? " hat Patent]" : "]");
    }
}
