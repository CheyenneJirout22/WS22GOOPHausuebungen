package haendler;

public abstract class Haendler {

	private final int id;
	protected String name;
	private String plz; //String -> A 1020
	private String ort;
	private String strasse;
	private String hausnummer; //String -> 71A
	private static int idzaehler = 0;
	protected double handelsvolumen;
	
	//fehlende erg�nzen
	public Haendler(String nameInp, double handelsvolumenInp, String plzInp, String ortInp, String strasseInp, String hausnummerInp) {
		this.id = idzaehler++;
		this.name = nameInp;
		this.handelsvolumen = handelsvolumenInp;
		this.plz = plzInp;
		this.ort = ortInp;
		this.strasse = strasseInp;
		this.hausnummer = hausnummerInp;
	}

	public String toString() {
		return "Haendler [id=" + id + ", name=" + name + ", plz=" + plz + ", ort=" + ort + ", strasse=" + strasse
				+ ", hausnummer=" + hausnummer + ", handelsvolumen=" + handelsvolumen + "]";
	}

	public abstract String print();

}
