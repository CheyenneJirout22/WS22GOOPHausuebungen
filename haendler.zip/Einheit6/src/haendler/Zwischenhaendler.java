package haendler;

public class Zwischenhaendler extends Haendler {

	private double verarbeitungsgeschwindigkeit;

	public Zwischenhaendler(String nameInp, double handelsvolumenInp, double verarbeitungsgeschwindigkeitInp, String plzInp, String ortInp, String strasseInp, String hausnummerInp) {
		super(nameInp, handelsvolumenInp, plzInp, hausnummerInp, ortInp, strasseInp);
		this.verarbeitungsgeschwindigkeit = verarbeitungsgeschwindigkeitInp;
	}

	public String toString() {
		return super.toString() + "Zwischenhaendler [verarbeitungsgeschwindigkeit=" + verarbeitungsgeschwindigkeit
				+ "]";
	}
	
	@Override
	public String print() {
		return "Print-methode des Zwischenhaendler mit Name: " + this.name;
	}

}
