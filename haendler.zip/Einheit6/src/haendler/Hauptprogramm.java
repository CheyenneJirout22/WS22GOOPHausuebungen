package haendler;

import java.util.ArrayList;

public class Hauptprogramm {

	public static void main(String[] args) {

		Grosshaendler g = new Grosshaendler("Rewe", 230.2, 180.2, 5, "1200", "hausgasse", "23", "wien");
		System.out.println(g);
		
		Zwischenhaendler z = new Zwischenhaendler("Billa", 100.2, 40.2, "1200", "hausgasse", "23", "wien");
		System.out.println(z);
		
		ArrayList<Haendler> haendler = new ArrayList<Haendler>();
		haendler.add(g);
		haendler.add(z);
		
		for (Haendler h : haendler) {
			System.out.println("Aufruf der toString-Methode: " + h);
			System.out.println("Aufruf der print-Methode: " + h.print());
			
			if (h instanceof Grosshaendler) {
				System.out.println("Die Variable h zeigt jetzt auf ein Grosshaendler!!" + h);
				Grosshaendler grossh = (Grosshaendler)h;
				int anzahlMitarbeiter  = grossh.getAnzahlMitarbeiter();
				System.out.println("Anzahl Mitarbeiter : " + anzahlMitarbeiter);
			}
			
		}
		

	}

}
