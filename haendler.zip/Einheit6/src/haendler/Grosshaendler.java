package haendler;

public class Grosshaendler extends Haendler{

	private double maxLagerkapazitaet;
	private int anzahlMitarbeiter;
	
	public Grosshaendler(String nameInp, double handelsvolumenInp, double maxLagerkapazitaetInp, int anzahlMitarbeiterInp, String plzInp, String ortInp, String strasseInp, String hausnummerInp) {
		super(nameInp, handelsvolumenInp, plzInp, hausnummerInp, ortInp, strasseInp);
		this.maxLagerkapazitaet = maxLagerkapazitaetInp;
		this.anzahlMitarbeiter = anzahlMitarbeiterInp;
	}

	public String toString() {
		return super.toString() + "Grosshaendler [maxLagerkapazitaet=" + maxLagerkapazitaet + ", anzahlMitarbeiter=" + anzahlMitarbeiter
				+ "]";
	}
	
	@Override
	public String print() {
		return "Print-methode des Grosshaendler mit Name: " + this.name;
	}

	public int getAnzahlMitarbeiter() {
		return anzahlMitarbeiter;
	}
	
	
	

}
