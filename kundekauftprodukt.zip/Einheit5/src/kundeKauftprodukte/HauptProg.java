package kundeKauftprodukte;

import java.util.ArrayList;
import java.util.Scanner;

public class HauptProg {

	public static void main(String[] args) {
		Kunde k = new Kunde("Max", "Muster", 3500.0);
//		System.out.println(k);

		ArrayList<Produkt> produkte = new ArrayList<Produkt>();
		produkte.add(new Produkt("Uhr", 1000));
		produkte.add(new Produkt("Ring", 500));
		produkte.add(new Produkt("Hose", 100));
		produkte.add(new Produkt("T-Shirt", 30));
		produkte.add(new Produkt("Laptop", 1500));
		produkte.add(new Produkt("Socken", 10));
		produkte.add(new Produkt("Brille", 350));
		produkte.add(new Produkt("Halstuch", 20));
		produkte.add(new Produkt("Handy", 1100));
		produkte.add(new Produkt("Monitor", 300));

		int inp = 0;
//		for(Produkt p : produkte) 
//			System.out.println(p);

		Scanner s = new Scanner(System.in);
		do {
			System.out.println("1 Neues Produkt\n2 Ausgabe\n3 Verkaufen\n4 Exit");
			inp = s.nextInt();
			switch (inp) {
			case 1:
				for (Produkt p : produkte)
					System.out.println(p);
				System.out.println("Welches Produkt kaufen?");
				int prodId = s.nextInt();
				Produkt prod = null;
				for (Produkt p : produkte) {
					if (p.getID() == prodId) {
						prod = p;
						break;
					}
				}
				if (prod == null) {
					System.out.println("Das Produkt gibt es nicht");
				} else {
					boolean res = k.addProdukt(prod);
					if (res) {
						System.out.println("Produkt gekauft");
					} else {
						System.out.println("Produkt konnte nicht gekauft werden");
					}
				}
				break;
			case 2:
				System.out.println("Kunde: " + k);
				break;
			case 3:
				System.out.println("Welches Produkt verkaufen?");
				int prodId2 = s.nextInt();
				boolean res2 = k.removeProdukt(prodId2);
				if (res2) {
					System.out.println("Produkt verkauft");
				} else {
					System.out.println("Produkt konnte nicht verkauft werden");
				}
				break;
			case 4:
				break;
			default:
				System.out.println("Falsche Eingabe!");
			}

		} while (inp != 4);

//		Produkt p = new Produkt("Uhr", 1000.0);
//		System.out.println(p);
//		
//		System.out.println(p.setPreis(1100));
//		
//		System.out.println(k.addProdukt(p));
//		System.out.println(k.addProdukt(p));
//		System.out.println(k);

	}
}
