package kundeKauftprodukte;

public class Produkt {

	private final int ID;
	private static int zaehler = 0;
	private String name;
	private double preis;
	private Kunde kunde;

	// Constructor
	public Produkt(String nameInp, double preisInp) {
		this.ID = ++Produkt.zaehler;
		this.name = nameInp;
		this.preis = preisInp;
		this.kunde = null;
	}

	// change price (max 10%)
	public boolean setPreis(double preisInp) {
		if (preisInp > (this.preis * 1.1) || preisInp < (this.preis * 0.9))
			return false;
		this.preis = preisInp;
		return true;
	}

	// Kunde hinzuzuf�gen
	public boolean addKunde(Kunde k) {
		if (this.kunde != null)
			return false;
		this.kunde = k;
		return true;
	}

	public void removeKunde() {
		this.kunde = null;
	}

	public double getPreis() {
		return this.preis;
	}

	public int getID() {
		return this.ID;
	}

	public String toString() {
		return "Produkt [ID=" + ID + ", name=" + name + ", preis=" + preis + "]";
	}

}