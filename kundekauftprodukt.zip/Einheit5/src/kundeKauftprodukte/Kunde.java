package kundeKauftprodukte;

import java.util.ArrayList;

public class Kunde {

	private final int ID;
	private String vorname;
	private String nachname;
	private double verfBudget;
	private static int zaehler = 1;
	private ArrayList<Produkt> produkte;

	public Kunde(String vornameInp, String nachnameInp, double verfBudgetInp) {
		this.ID = Kunde.zaehler++;
		this.vorname = vornameInp;
		this.nachname = nachnameInp;
		this.verfBudget = verfBudgetInp;
		this.produkte = new ArrayList<Produkt>();
	}

	public boolean addProdukt(Produkt p) {
		if (this.produkte.size() >= 4)
			return false;
		if (p.getPreis() > this.verfBudget)
			return false;
		boolean prodRetVal = p.addKunde(this);
		if (!prodRetVal)
			return false;
		this.verfBudget -= p.getPreis();
		this.produkte.add(p);
		return true;
	}

	public boolean removeProdukt(int prodId) {
		Produkt prod = null;
		for (Produkt p : this.produkte) {
			if (p.getID() == prodId) {
				prod = p;
				break;
			}
		}
		if (prod == null)
			return false;
		prod.removeKunde();
		this.verfBudget += prod.getPreis();
		this.produkte.remove(prod);
		return true;
	}

	public String toString() {
		return "Kunde [ID=" + ID + ", vorname=" + vorname + ", nachname=" + nachname + ", verfBudget=" + verfBudget
				+ ", produkte=" + produkte + "]";
	}

}
