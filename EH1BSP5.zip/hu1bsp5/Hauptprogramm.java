package hu1bsp5;

public class Hauptprogramm {

	public static void main(String[] args) {
		Auto a1 = new Auto();
		System.out.println(a1);
		
		a1.beschleunigen(50);
		System.out.println(a1);
		
		a1.verlangsamern(30);
		System.out.println(a1);
		
		Auto a2 = new Auto(2, 220);
		System.out.println(a2);
		
		a2.beschleunigen(45.5);
		System.out.println(a2);
		
		a2.verlangsamern(70);
		System.out.println(a2);
	}

}
