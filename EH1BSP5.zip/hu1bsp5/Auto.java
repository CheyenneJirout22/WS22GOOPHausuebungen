package hu1bsp5;

public class Auto {
		private int tuer;
		private int ps;
		private double geschwindigkeit;
		
		public Auto() {
			this.tuer = 4;
			this.ps = 70;
			this.geschwindigkeit = 0;
		}
		
		public Auto(int tuer, int PS) {
			this.tuer = tuer;
			this.ps = PS;
			this.geschwindigkeit = 0;
		}
		
		public void beschleunigen(double gwsChange) {
			this.geschwindigkeit += gwsChange;
		}
		public void verlangsamern(double gwsChange) {
			
			if (geschwindigkeit <= gwsChange) {
				geschwindigkeit = 0; 
			}
			geschwindigkeit -= gwsChange;
		}
		
		public String toString() {
			return "[" + 
					this.tuer + "T�ren, " +
					this.ps + "PS, " +
					this.geschwindigkeit +
					"km/h" +
					"]";
		}
}
