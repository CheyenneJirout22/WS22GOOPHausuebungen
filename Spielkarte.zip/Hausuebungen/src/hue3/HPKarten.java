package hue3;

public class HPKarten {

	public static void main(String[] args) 
	{
		Spielkarte a = new Spielkarte();
		System.out.println(a);
		//Spielkarte b = new Spielkarte(Kartenwert.BUBE);
		//System.out.println(b);
		Spielkarte c = new Spielkarte (Kartenfarbe.HERZ, Kartenwert.AS);
		System.out.println(c);
		
		System.out.println("Das ERgebnis: " + a.sticht(c));
		
		/*
		a.getFarbe();
		System.out.println(a.getFarbe());
		System.out.println(a.getFarbe().compareTo(b.getFarbe()));
		
		if (a.getFarbe().compareTo(b.getFarbe()) < 0)
		{
			System.out.println("Karte b sticht Karte a!");
		}
		else if (a.getFarbe().compareTo(b.getFarbe()) > 0) 
		{
			System.out.println("Karte a sticht Karte b!");
		}
		else if (a.getFarbe().compareTo(b.getFarbe()) == 0)
		{
			if(a.getWert().compareTo(b.getWert())<0)
			{
				System.out.println("Karte b sticht Karte a!");
			}
			else if (a.getWert().compareTo(b.getWert())>0)
			{
				System.out.println("Karte a sticht Karte b!");
			}
			else if (a.getWert().compareTo(b.getWert())==0)
			{
				System.out.println("Unentschieden, da gleiche Karten!");
			}
		}
		
		Kartenwert karteW1 = a.getWert();
		Kartenwert karteW2 = c.getWert();
		Kartenfarbe karteF1 = a.getFarbe();
		Kartenfarbe karteF2 = c.getFarbe();
		
		if (karteF1.compareTo(karteF2) > 0)
		{
			System.out.println("Die Karte mit den Werten " + karteF1 + "," + karteW1 + " sticht die Karte " + karteF2 +","+ karteW2 + "!");
		}
		else if (karteF1.compareTo(karteF2) < 0) 
		{
			System.out.println("Die Karte mit den Werten " + karteF2 + "," + karteW2 + " sticht die Karte " + karteF1 +","+ karteW1+ "!");
		}
		else 
		{
			if(karteW1.compareTo(karteW2)<0)
			{
				System.out.println("Die Karte mit den Werten " + karteF2 + "," + karteW2 + " sticht die Karte " + karteF1 +","+ karteW1 + "!");
			}
			else if (karteW1.compareTo(karteW2)>0)
			{
				System.out.println("Die Karte mit den Werten " + karteF1 + "," + karteW1 + " sticht die Karte " + karteF2 +","+ karteW2 + "!");
			}
			else
			{
				System.out.println("Unentschieden, da gleiche Karten! Karte 1: " + karteF1 +","+ karteW1 + " Karte 2: " + karteF2 +","+ karteW2 + "!");
			}
		}
		*/
		
		
	}

}
