package hue3;

public enum Kartenwert 
{
	ZEHN,BUBE,DAME,KOENIG,AS
}
