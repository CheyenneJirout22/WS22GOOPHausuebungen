package hue3;

public enum Kartenfarbe 
{
	PIK,TREFF,KARO,HERZ
}
