package hue3;

public class Spielkarte 
{
	private Kartenwert wert;
	private Kartenfarbe farbe;
	
	
	public Spielkarte()
	{
		this.farbe = Kartenfarbe.HERZ;
		this.wert = Kartenwert.AS;
		
	}
	
	public Spielkarte(Kartenwert wertInp)
	{
		this.farbe = Kartenfarbe.HERZ;
		this.wert = wertInp;
		
	}
	public Spielkarte(Kartenfarbe farbeInp, Kartenwert wertInp)
	{
		this.farbe = farbeInp;
		this.wert = wertInp;
		
	}
	public String toString( ) 
	{
		return "[" + 
				this.farbe + "," +
				this.wert + 
				"]";
	}
	
	public Kartenfarbe getFarbe() 
	{
		return this.farbe;
	}
	
	public Kartenwert getWert() 
	{
		return this.wert;
	}
	public int sticht(Spielkarte karte2) 
	{
		if (this.farbe.compareTo(karte2.farbe) > 0)
		{
			return 1;
		}
		else if (this.farbe.compareTo(karte2.farbe) < 0) 
		{
			return -1;
		}
		else 
		{
			if(this.wert.compareTo(karte2.wert)>0)
			{
				return 1;
			}
			else if (this.wert.compareTo(karte2.wert)<0)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
	public int sticht2(Spielkarte karte2) 
	{
		// Wenn der Farbenwert gleich ist (=0) wird der Kartevergleich retourniert
		if (this.farbe.compareTo(karte2.farbe) == 0) 
		{
			return this.wert.compareTo(karte2.wert);
		}
		else
		{
			// Es wird der Farbenvergleich retourniert
			return this.farbe.compareTo(karte2.farbe);
		}
	}
}
