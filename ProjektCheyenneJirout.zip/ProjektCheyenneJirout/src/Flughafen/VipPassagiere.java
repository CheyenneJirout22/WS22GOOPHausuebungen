package Flughafen;

public class VipPassagiere extends Passagiere {
	
	private double geflogeneKM;
	
	public VipPassagiere(int idInp, String vornameInp, String nachnameInp, double geflogenKMInp, Status statusInp) {
		super(idInp, vornameInp, nachnameInp, statusInp);
		this.geflogeneKM = geflogenKMInp;
		this.maxGewicht = 30;
	}

	public String toString() {
		return "[VIP "+ vorname + " " + nachname + " " + status + "]";
	}
}
