package Flughafen;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		//Passagiere p = new Passagiere(1, "Hubert", "Maier", 'B');
		
		ArrayList<Flug> willWegVon = new ArrayList<Flug>();
		
	}

}
/*
[DQ777 Wien New York 7000 : 
[Hubert Maier B], 
[VIP Karin HuberC], 
[Romana Nowak F]]
*/