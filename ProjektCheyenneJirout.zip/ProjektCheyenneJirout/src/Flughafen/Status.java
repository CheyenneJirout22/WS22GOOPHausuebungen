package Flughafen;

public enum Status {
	C, B, F
	//C -> bereits eingecheckt
	//B -> bereits an Bord
	//F -> fehlt noch
}
