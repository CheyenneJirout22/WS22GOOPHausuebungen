package Flughafen;

public enum Material {
	STOFF, LEDER, PLASTIK, METALL

}
