package Flughafen;

public enum Farbe {

	ROT, GRUEN, BLAU, CYAN, MAGENTA, GELB, WEISS, SCHWARZ, SILBER
}
