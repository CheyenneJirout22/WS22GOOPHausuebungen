package Flughafen;

public class Ticket extends Flug {

	private final int ticketnr;
	
	public Ticket (String bezeichnungInp, String abflugortInp, String ankunftsortInp, double entfernungKmInp, String kennzeichenInp, int ticketnrInp, int anzahlSitzplaetzeInp) throws Exception{
		super(bezeichnungInp, abflugortInp, ankunftsortInp, entfernungKmInp, kennzeichenInp, anzahlSitzplaetzeInp);
		this.ticketnr = ticketnrInp;
	}

	public int getTicketnr() {
		return ticketnr;
	}
	
	
}
