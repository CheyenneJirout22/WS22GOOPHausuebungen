package Flughafen;

public class Gepaeck {
	
	private double gewicht;
	private Material material;
	private Farbe farbe;
	
	public Gepaeck(double gewichtInp, Material materialInp, Farbe farbeInp) {
		this.gewicht = gewichtInp;
		this.material = materialInp;
		this.farbe = farbeInp;
		
	}

	public double getGewicht() {
		return gewicht;
	}
}
