package Flughafen;

import java.util.ArrayList;

public class Flug {
	
	private final String bezeichnung;
	private String abflugort;
	private String ankunftsort;
	private double entfernungKm;
	private int anzahlSitzplaetze;
	private String kennzeichen;
	
	
	public Flug(String bezeichnungInp, String abflugortInp, String ankunftsortInp, double entfernungKmInp, String kennzeichenInp, int anzahlSitzplaetzeInp) throws Exception{
		this.bezeichnung = bezeichnungInp;
		this.abflugort = abflugortInp;
		this.ankunftsort = ankunftsortInp;
		this.entfernungKm = entfernungKmInp;
		this.kennzeichen = kennzeichenInp;	
		this.anzahlSitzplaetze = anzahlSitzplaetzeInp;
	}

	public String getAbflugort() {
		return abflugort;
	}


	public String toString() {
		return bezeichnung + " " + abflugort + " " + ankunftsort + " " + entfernungKm + ":";
	}

	/*boolean alleAnBord(), welche �berpr�ft, ob alle Passagiere, 
	 * die f�r einen bestimmten Flug Gep�ck abgegeben haben auch an Bord sind*/
	public void alleAnBoard() {
		if(anzahlSitzplaetze == anzahlPassagiere) {
			
		}
		return true;
	}
	
	/*double ladeGewicht(), die das Gesamtgewicht der an
	Bord eines Fluges befindlichen Gep�ckst�cke berechnet*/
	public void ladeGewicht() {
		return;
	}
	
}
