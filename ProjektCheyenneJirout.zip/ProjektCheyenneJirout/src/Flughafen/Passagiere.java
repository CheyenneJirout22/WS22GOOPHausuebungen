package Flughafen;

import java.util.ArrayList;

public class Passagiere {

	private final int id;
	protected String vorname;
	protected String nachname;
	protected int maxGewicht;
	protected Status status;
	private ArrayList<Ticket> tickets;
	
	public Passagiere(int idInp, String vornameInp, String nachnameInp, Status statusInp){
		this.id = idInp;
		this.vorname = vornameInp;
		this.nachname = nachnameInp;
		this.status = statusInp;
		this.maxGewicht = 20;
	}

	public String toString() {
		return "["+ vorname + " " + nachname + " " + status + "]";
	}

	//Passagiere k�nnen Tickets f�r die Fl�ge erwerben()
	//Dabei kann jeder Passagier f�r einen
	//Flug nur ein Ticket kaufen, es d�rfen f�r jeden Flug auch nicht mehr Tickets verkauft werden,
	//als es Sitzpl�tze gibt.
	public boolean erwerben(Ticket t) {
		this.tickets.add(t);
		return true;
	}
	
	/*Beim einchecken() kann jeder Passagier (falls er/sie ein Tickt f�r den Flug hat) ein Gep�ckst�ck abgeben, 
	 * welches sofort an Bord des Flugzeuges gebracht wird. Dieses darf maximal 20
	kg wiegen. Gep�ckst�cke von VIP-Passagiere d�rfen bis zu 30 kg wiegen.*/
	public void eincheck() {
		if(tickets.size() >= 1) {
			
		}
		return;
	}
	
	/*Beim boarden() betreten die Passagiere dann das Flugzeug. Diese m�ssen kein Gep�ckst�ck
	abgegeben haben, aber nat�rlich ein Ticket f�r den Flug besitzen*/
	public void boarden() {
		return;
	}
	
	
}
