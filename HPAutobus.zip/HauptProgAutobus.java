package hausuebung;

public class HauptProgAutobus
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		Autobus b1 = new Autobus();
		
		b1.betrieb(1);
		
		b1.einsteigen(66);
		b1.aussteigen(5);
			

		System.out.println(b1);

	}

}
