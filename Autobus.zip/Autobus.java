package hausuebung;

public class Autobus
{
	private String ID;
	private int hochsg;
	private int PS;
	private int platze;
	private String nameFahrerV;
	private String nameFahrerN;
	private int mitfahrer;
	
	public Autobus()
	{
		ID = "123456";
		hochsg = 150;
		PS = 100;
		platze = 45;
		mitfahrer = 0;
		nameFahrerV = "NULL";
		nameFahrerN = "NULL";
	}
	
	public void betrieb (int betrieb)
	{
		if (betrieb!=1) return;
		nameFahrerV = "Karl";
		nameFahrerN = "Franz";
	}

	public void einsteigen (int einsteigende)
	{
		if (nameFahrerN=="NULL" || nameFahrerV=="NULL") return;
		if (mitfahrer+einsteigende>platze)
		{
			this.mitfahrer = platze;
		}
		else
		{
			this.mitfahrer += einsteigende;
		}
	}
	
	public void aussteigen (int aussteigende)
	{
		if (nameFahrerN=="NULL" || nameFahrerV=="NULL") return;
		if (mitfahrer-aussteigende<0)
		{
			this.mitfahrer = 0;
		}
		this.mitfahrer -= aussteigende;
	}
	
	public String toString()
	{
		if (nameFahrerN!="NULL" || nameFahrerV!="NULL")
		{
			return "("+
			this.ID + "," +
			this.nameFahrerV  + " " +
			this.nameFahrerN + "," +
			this.hochsg + "," +
			this.PS + "," +
			this.mitfahrer + "," +
			this.platze + ")";	
		}
		else
		{
			return "Der Autobus ist nicht im betrieb: ("+
			this.ID + "," +
			this.hochsg + "," +
			this.PS + "," +
			this.platze + ")";
		}
		
	}
	
}
