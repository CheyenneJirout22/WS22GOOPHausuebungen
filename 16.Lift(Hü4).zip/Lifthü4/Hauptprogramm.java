package Lifth�4;

public class Hauptprogramm {

	public static void main(String[] args) {
		Lift l1 = new Lift ();
		System.out.println(l1);
		Lift l2 = new Lift ("xy", 3, 300, 400); //gebauedename, Stockwerk, stockwerkhohe in cm, geschwindigkeit cm/sek
		l2.rufen(4); //wollen 3 Stockwerke hinauf fahren
		System.out.println(l2);
		System.out.println(); // Zeit Ausgabe ?
		
	}

}
