package Lifth�4;

public class Lift { // Problem mit Zeitausgabe nur
	
	
	//Instanzvariablen
	private String nameGebaeude;
	private int stockwerk=0;
	private double hoehe; //(in cm)
	private double geschwindigkeit; // (in cm pro Sek) 
	private double zeit; 
	
	
	//Konstruktoren 
	public Lift() //leerer Konstruktor mit Standard Werten belegen
	{	
		this.nameGebaeude = "Xy";
		this.stockwerk= 0;  
		this.hoehe= 300;
		this.geschwindigkeit=250 ;
		this.zeit=0;
	}
	
	public Lift(String nameGebaeudeInp, int stockwerkInp, double hoeheInp, double geschwindigkeitInp ) { //nur INP 
		this.nameGebaeude = nameGebaeudeInp;
		this.stockwerk= stockwerkInp;  
		this.hoehe= hoeheInp;
		this.geschwindigkeit= geschwindigkeitInp;
		this.zeit=0;
	}
	
	
	//Methode rufen
	public double rufen (int stockwerkInp ) { //
		int differenz= this.stockwerk - stockwerkInp; // 0 zb - 3= -3
		if(differenz <0) 
		{
			differenz=differenz*(-1); //Differenz auf positiv setzen f�r weitere Berechnung mit v  
		}
		else //Fehlerausgabe wenn der Stockwerk derselbe ist dann f�hrt nicht
		{
			System.out.println("Keine Zeitausgabe weil Lift nicht f�hrt");
		}
		double weg = (double) (differenz*hoehe); //Weg erzeugen (s)  
		zeit= (double) (geschwindigkeit/weg); // t = v / s  
		this.stockwerk = stockwerkInp; //momenatene Stockwerk wird gew�nschte Stockwerk eingetragen
		return zeit; 
	}
	
	
	//Getter / Setter f�r alle Instanzvariablen 
	
	//1. nameGebaeude
	public void setNameGebaeude(String nameGebaeudeInp) { //name nicht null zb oder leer 
		if (nameGebaeudeInp == null || nameGebaeudeInp.trim().isEmpty()) return;
		this.nameGebaeude = nameGebaeudeInp.trim();
	}
	public String getNameGebaeude() {
		return this.nameGebaeude;
	}
	
	//2. stockwerk
	public void setStockwerk (int stockwerkInp) {
		if ((stockwerk > 5) || (stockwerk < -2)) return; //Es soll insg 8 Stockwerke geben von -2 bis obersten 5. 
		this.stockwerk = stockwerkInp;
	}
	public int getStockwerk() {
		return this.stockwerk;
	}
	
	//3. hoehe
	public void setHoehe (double hoeheInp) {
		if ((hoehe > 300) || (hoehe <300)) return; //stockwerkhoehe soll zb nicht gr��er als 3 m sein und auch nicht gr��er dh soll genau 3 Meter sein 
		this.hoehe = hoeheInp; 
	}
	public double getHoehe() {
		return this.hoehe; 
	}
	
	//4. geschwindigkeit
	public void setGeschwindigkeit(double geschwindigkeitInp) { 
		if (geschwindigkeitInp < 0) return; //v darf nicht negativ sein
		this.geschwindigkeit = geschwindigkeitInp;
	}
	public double getGeschwindigkeit() {
		return this.geschwindigkeit;
	}
	
	
	//String toString Methode
	public String toString() {
		return "[" +
			this.nameGebaeude + ", " +
			this.stockwerk + ", " +
			this.hoehe + ", " + 
			this.geschwindigkeit + ", " +
			this.zeit + ", "+
			"]";
	}

	
}
