package PersonKonto;

public class Konto {
	
	private double kontonummer;
	private double kontostand;
	private double zinssatz;
	
	//Konstruktor
		public Konto(double kontonummerInp, double kontostandInp, double zinssatzInp) {
		//super();
		this.kontonummer = kontonummerInp;
		this.kontostand = kontostandInp;
		this.zinssatz = zinssatzInp;
	}
	
	//Getter
	public double getKontonummer() {
		return this.kontonummer;
	}

	public double getKontostand() {
		return this.kontostand;
	}
	public double getZinssatz() {
		return this.zinssatz;
	}
	
	//Setter
	public void setKontostand(double kontostand) {
		this.kontostand = kontostand;
	}

	public void setZinssatz(double zinssatz) {
		this.zinssatz = zinssatz;
	}
	
	//To String Methode
	public String toString() {
		return "[" + 
			this.kontonummer + ", " +
			this.kontostand + ", " +
			this.zinssatz + ", " + 
			"]";
	}

	
	
	

}
