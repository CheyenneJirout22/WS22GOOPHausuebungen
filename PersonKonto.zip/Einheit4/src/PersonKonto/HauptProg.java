package PersonKonto;

import java.util.ArrayList;

import uebung.Besitzer;
import uebung.Haustier;

public class HauptProg {

	public static void main(String[] args) {

		Konto k = new Konto(123345, 300000, 2.5);
		//System.out.println(k);
		
//		ArrayList<Konto> konto = new ArrayList<Konto>();
//		konto.add(k); 
//		System.out.println("Konto:");
//		for (int i = 0; i < konto.size(); i++) {
//			System.out.println("Das Konto: " + konto.get(i));
//		}
		
		Person p = new Person("Cheyenne", "Jirout", "22/10/2000");
		//System.out.println("Person: " + p);
		p.addKonto(k);
		System.out.println("Person: " + p);
	}
}
//Person --> Konto
//Konto --> nix
