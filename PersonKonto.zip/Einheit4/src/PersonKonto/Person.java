package PersonKonto;

import PersonKonto2.PersonKontoMehr;
import uebung.Besitzer;

public class Person {
	
	private String vorname;
	private String nachname;
	private String geburtsdatum;
	private final int personID;
	private static int zaehler = 1;
	private Konto konto;
	
	//Konstruktor
	public Person(String vornameInp, String nachnameInp, String geburtsdatumInp) {
		this.personID = Person.zaehler++;
		this.vorname = vornameInp;
		this.nachname = nachnameInp;
		this.geburtsdatum = geburtsdatumInp;
		this.konto = null;
	}
	//Methode um Vorname hinzuzuf�gen
	public void changeName(String neuerVorname) {
		this.vorname = neuerVorname;
	}
	
	// Methode um Konto hinzuzuf�gen
	public void addKonto(Konto k) {
		if (this.konto != null) return; 
		
		this.konto = k;
	}
	
	//To String Methode
	public String toString() {
		return "[" + 
			this.personID + ", " +
			this.vorname + ", " +
			this.nachname + ", " +
			this.konto + 
			"]";
	}
}
